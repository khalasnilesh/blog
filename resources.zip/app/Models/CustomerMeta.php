<?php 

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class CustomerMeta extends Model
{
    //
    protected $collection = 'customer_meta';
    // protected $connection = 'mongodb';
}