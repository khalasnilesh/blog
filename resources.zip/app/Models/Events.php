<?php 

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class Events extends Model
{
    //
    protected $collection = 'events';
    // protected $connection = 'mongodb';
}