<?php 

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class Plugins extends Model
{
    //
    protected $collection = 'plugins';
    // protected $connection = 'mongodb';
}