<?php 

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class Webhooks extends Model
{
    //
    protected $collection = 'webhooks';
    // protected $connection = 'mongodb';
}