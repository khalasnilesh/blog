<?php 

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class SiteMeta extends Model
{
    //
    protected $collection = 'sitemeta';
    // protected $connection = 'mongodb';
}