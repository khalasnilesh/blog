<?php 

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class Sites extends Model
{
    //
    protected $collection = 'sites';
    // protected $connection = 'mongodb';
}