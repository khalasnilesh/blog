<?php 

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class Reports extends Model
{
    //
    protected $collection = 'reports';
    // protected $connection = 'mongodb';
}